# VARIABLES GLOBALES
tokens = []
pos = 0

# MANEJO DE ERRORES
def error(token_esperado):
    global pos
    if pos < len(tokens):
        raise SyntaxError(
            f"Error sintáctico: se esperaba '{token_esperado}' pero se encontró '{tokens[pos]}'"
        )
    else:
        raise SyntaxError(
            f"Error sintáctico: se esperaba '{token_esperado}' pero se llegó al final de la entrada"
        )


# FUNCIÓN PAREA (MATCH)
def parea(token_esperado):
    global pos

    if pos < len(tokens) and tokens[pos] == token_esperado:
        print(f" Match: {tokens[pos]}")
        pos += 1
    else:
        error(token_esperado)


# ANALIZADOR DESCENDENTE (ASDR)

def proposicion():
    global pos

    if pos < len(tokens) and tokens[pos] == "if":
        print(" proposicion condicional")
        condicional()
    elif pos < len(tokens) and tokens[pos] == "ID":
        print(" proposicion asignacion")
        asignacion()
    else:
        error("proposicion")


def asignacion():
    print(" asignacion")
    parea("ID")
    parea(":=")
    expresion()


def condicional():
    print(" condicional")
    parea("if")
    expresion()
    parea("then")
    proposicion()

    if pos < len(tokens) and tokens[pos] == "else":
        parea("else")
        proposicion()


def expresion():
    global pos

    print(" expresion")

    if pos < len(tokens) and tokens[pos] == "ID":
        parea("ID")
    elif pos < len(tokens) and tokens[pos] == "NUM":
        parea("NUM")
    else:
        error("expresion")


# MAIN (PRUEBAS)
def main():
    global tokens, pos

    tokens = ["if", "ID", "then", "if", "ID", "then", "ID", ":=", "NUM", "else", "ID", ":=", "NUM"]

    pos = 0

    try:
        proposicion()

        if pos == len(tokens):
            print("\n Cadena aceptada completamente.")
        else:
            print("\n Error: quedaron tokens sin consumir.")

    except SyntaxError as e:
        print(f"\n{e}")


# PUNTO DE ENTRADA
if __name__ == "__main__":
    main()

grammar CrudNoSQL;

// Parser Rules (minúsculas)

program
    : statement (';' statement)* ';' EOF
    ;

statement
    : create_stmt
    | read_stmt
    | update_stmt
    | delete_stmt
    ;

create_stmt
    : CREATE identifier WITH json_object
    ;

read_stmt
    : READ identifier where_clause?
    ;

update_stmt
    : UPDATE identifier SET assignments where_clause?
    ;

delete_stmt
    : DELETE identifier where_clause?
    ;

where_clause
    : WHERE expression
    ;

// Expresiones (precedencia)

expression
    : or_expr
    ;

or_expr
    : and_expr (OR and_expr)*
    ;

and_expr
    : not_expr (AND not_expr)*
    ;

not_expr
    : NOT not_expr
    | comparison_expr
    ;

comparison_expr
    : primary_expr (comp_operator primary_expr)?
    ;

primary_expr
    : literal
    | field_access
    | LPAREN expression RPAREN
    ;

comp_operator
    : EQ | NEQ | GT | LT | GTE | LTE | IN
    ;

// Acceso a campos

field_access
    : identifier (DOT identifier)*
    ;

// UPDATE

assignments
    : assignment (COMMA assignment)*
    ;

assignment
    : field_access ASSIGN value
    ;

// JSON 

json_object
    : LBRACE (pair (COMMA pair)*)? RBRACE
    ;

pair
    : identifier COLON value
    ;

json_array
    : LBRACKET (value (COMMA value)*)? RBRACKET
    ;

value
    : literal
    | json_object
    | json_array
    ;

// Literales

literal
    : STRING
    | NUMBER
    | TRUE
    | FALSE
    | NULL
    ;

// Identificadores

identifier
    : IDENTIFIER
    ;

// Lexer Rules (MAYÚSCULAS)

// Keywords
CREATE : 'CREATE';
READ   : 'READ';
UPDATE : 'UPDATE';
DELETE : 'DELETE';
WITH   : 'WITH';
SET    : 'SET';
WHERE  : 'WHERE';
AND    : 'AND';
OR     : 'OR';
NOT    : 'NOT';
IN     : 'IN';

// Operadores
EQ  : '==';
NEQ : '!=';
GTE : '>=';
LTE : '<=';
GT  : '>';
LT  : '<';
ASSIGN : '=';

// Delimitadores
LBRACE   : '{';
RBRACE   : '}';
LBRACKET : '[';
RBRACKET : ']';
LPAREN   : '(';
RPAREN   : ')';
COMMA    : ',';
COLON    : ':';
DOT      : '.';

// Literales
TRUE  : 'true';
FALSE : 'false';
NULL  : 'null';

STRING
    : '"' (~["\\] | '\\' .)* '"'
    ;

NUMBER
    : DIGIT+ ('.' DIGIT+)?
    ;

// Identificador
IDENTIFIER
    : LETTER (LETTER | DIGIT | '_')*
    ;

// Fragmentos
fragment LETTER : [a-zA-Z];
fragment DIGIT  : [0-9];

// Ignorar espacios
WS
    : [ \t\r\n]+ -> skip
    ;

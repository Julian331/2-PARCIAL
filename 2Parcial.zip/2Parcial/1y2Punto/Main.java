import org.antlr.v4.runtime.*;
import org.antlr.v4.runtime.tree.*;

import java.io.FileInputStream;
import java.io.InputStream;

public class Main {

    public static void main(String[] args) throws Exception {

        if (args.length == 0) {
            System.out.println("Uso: java Main <archivo>");
            return;
        }

        String inputFile = args[0];
        InputStream is = new FileInputStream(inputFile);

        // Crear flujo de entrada
        CharStream input = CharStreams.fromStream(is);

        // Lexer
        CrudNoSQLLexer lexer = new CrudNoSQLLexer(input);

        // Tokens
        CommonTokenStream tokens = new CommonTokenStream(lexer);

        // Parser
        CrudNoSQLParser parser = new CrudNoSQLParser(tokens);

        ParseTree tree = parser.program();

        System.out.println("\n=== ÁRBOL SINTÁCTICO ===\n");
        printTree(tree, parser, 0);
    }

    public static void printTree(ParseTree tree, Parser parser, int level) {
        String indent = "  ".repeat(level);
        String nodeText = Trees.getNodeText(tree, parser);

        System.out.println(indent + nodeText);

        for (int i = 0; i < tree.getChildCount(); i++) {
            printTree(tree.getChild(i), parser, level + 1);
        }
    }
}

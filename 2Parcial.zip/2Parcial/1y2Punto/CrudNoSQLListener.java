// Generated from CrudNoSQL.g4 by ANTLR 4.13.1
import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link CrudNoSQLParser}.
 */
public interface CrudNoSQLListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#program}.
	 * @param ctx the parse tree
	 */
	void enterProgram(CrudNoSQLParser.ProgramContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#program}.
	 * @param ctx the parse tree
	 */
	void exitProgram(CrudNoSQLParser.ProgramContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#statement}.
	 * @param ctx the parse tree
	 */
	void enterStatement(CrudNoSQLParser.StatementContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#statement}.
	 * @param ctx the parse tree
	 */
	void exitStatement(CrudNoSQLParser.StatementContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#create_stmt}.
	 * @param ctx the parse tree
	 */
	void enterCreate_stmt(CrudNoSQLParser.Create_stmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#create_stmt}.
	 * @param ctx the parse tree
	 */
	void exitCreate_stmt(CrudNoSQLParser.Create_stmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#read_stmt}.
	 * @param ctx the parse tree
	 */
	void enterRead_stmt(CrudNoSQLParser.Read_stmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#read_stmt}.
	 * @param ctx the parse tree
	 */
	void exitRead_stmt(CrudNoSQLParser.Read_stmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#update_stmt}.
	 * @param ctx the parse tree
	 */
	void enterUpdate_stmt(CrudNoSQLParser.Update_stmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#update_stmt}.
	 * @param ctx the parse tree
	 */
	void exitUpdate_stmt(CrudNoSQLParser.Update_stmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#delete_stmt}.
	 * @param ctx the parse tree
	 */
	void enterDelete_stmt(CrudNoSQLParser.Delete_stmtContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#delete_stmt}.
	 * @param ctx the parse tree
	 */
	void exitDelete_stmt(CrudNoSQLParser.Delete_stmtContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#where_clause}.
	 * @param ctx the parse tree
	 */
	void enterWhere_clause(CrudNoSQLParser.Where_clauseContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#where_clause}.
	 * @param ctx the parse tree
	 */
	void exitWhere_clause(CrudNoSQLParser.Where_clauseContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#expression}.
	 * @param ctx the parse tree
	 */
	void enterExpression(CrudNoSQLParser.ExpressionContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#expression}.
	 * @param ctx the parse tree
	 */
	void exitExpression(CrudNoSQLParser.ExpressionContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#or_expr}.
	 * @param ctx the parse tree
	 */
	void enterOr_expr(CrudNoSQLParser.Or_exprContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#or_expr}.
	 * @param ctx the parse tree
	 */
	void exitOr_expr(CrudNoSQLParser.Or_exprContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#and_expr}.
	 * @param ctx the parse tree
	 */
	void enterAnd_expr(CrudNoSQLParser.And_exprContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#and_expr}.
	 * @param ctx the parse tree
	 */
	void exitAnd_expr(CrudNoSQLParser.And_exprContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#not_expr}.
	 * @param ctx the parse tree
	 */
	void enterNot_expr(CrudNoSQLParser.Not_exprContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#not_expr}.
	 * @param ctx the parse tree
	 */
	void exitNot_expr(CrudNoSQLParser.Not_exprContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#comparison_expr}.
	 * @param ctx the parse tree
	 */
	void enterComparison_expr(CrudNoSQLParser.Comparison_exprContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#comparison_expr}.
	 * @param ctx the parse tree
	 */
	void exitComparison_expr(CrudNoSQLParser.Comparison_exprContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#primary_expr}.
	 * @param ctx the parse tree
	 */
	void enterPrimary_expr(CrudNoSQLParser.Primary_exprContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#primary_expr}.
	 * @param ctx the parse tree
	 */
	void exitPrimary_expr(CrudNoSQLParser.Primary_exprContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#comp_operator}.
	 * @param ctx the parse tree
	 */
	void enterComp_operator(CrudNoSQLParser.Comp_operatorContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#comp_operator}.
	 * @param ctx the parse tree
	 */
	void exitComp_operator(CrudNoSQLParser.Comp_operatorContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#field_access}.
	 * @param ctx the parse tree
	 */
	void enterField_access(CrudNoSQLParser.Field_accessContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#field_access}.
	 * @param ctx the parse tree
	 */
	void exitField_access(CrudNoSQLParser.Field_accessContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#assignments}.
	 * @param ctx the parse tree
	 */
	void enterAssignments(CrudNoSQLParser.AssignmentsContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#assignments}.
	 * @param ctx the parse tree
	 */
	void exitAssignments(CrudNoSQLParser.AssignmentsContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#assignment}.
	 * @param ctx the parse tree
	 */
	void enterAssignment(CrudNoSQLParser.AssignmentContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#assignment}.
	 * @param ctx the parse tree
	 */
	void exitAssignment(CrudNoSQLParser.AssignmentContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#json_object}.
	 * @param ctx the parse tree
	 */
	void enterJson_object(CrudNoSQLParser.Json_objectContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#json_object}.
	 * @param ctx the parse tree
	 */
	void exitJson_object(CrudNoSQLParser.Json_objectContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#pair}.
	 * @param ctx the parse tree
	 */
	void enterPair(CrudNoSQLParser.PairContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#pair}.
	 * @param ctx the parse tree
	 */
	void exitPair(CrudNoSQLParser.PairContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#json_array}.
	 * @param ctx the parse tree
	 */
	void enterJson_array(CrudNoSQLParser.Json_arrayContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#json_array}.
	 * @param ctx the parse tree
	 */
	void exitJson_array(CrudNoSQLParser.Json_arrayContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#value}.
	 * @param ctx the parse tree
	 */
	void enterValue(CrudNoSQLParser.ValueContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#value}.
	 * @param ctx the parse tree
	 */
	void exitValue(CrudNoSQLParser.ValueContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#literal}.
	 * @param ctx the parse tree
	 */
	void enterLiteral(CrudNoSQLParser.LiteralContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#literal}.
	 * @param ctx the parse tree
	 */
	void exitLiteral(CrudNoSQLParser.LiteralContext ctx);
	/**
	 * Enter a parse tree produced by {@link CrudNoSQLParser#identifier}.
	 * @param ctx the parse tree
	 */
	void enterIdentifier(CrudNoSQLParser.IdentifierContext ctx);
	/**
	 * Exit a parse tree produced by {@link CrudNoSQLParser#identifier}.
	 * @param ctx the parse tree
	 */
	void exitIdentifier(CrudNoSQLParser.IdentifierContext ctx);
}
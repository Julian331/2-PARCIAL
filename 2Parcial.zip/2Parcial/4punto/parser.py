tokens = []
pos = 0


# Función de error
def error(token_esperado):
    global pos
    if pos < len(tokens):
        raise SyntaxError(
            f"Error sintáctico: se esperaba '{token_esperado}' pero se encontró '{tokens[pos]}'"
        )
    else:
        raise SyntaxError(
            f"Error sintáctico: se esperaba '{token_esperado}' pero se llegó al final de la entrada"
        )


# Algoritmo parea (match)
def parea(token_esperado):
    global pos

    if pos < len(tokens) and tokens[pos] == token_esperado:
        print(f"Match: {tokens[pos]}")
        pos += 1
    else:
        error(token_esperado)


# Gramática (ASDR)

def proposicion():
    global pos
    if pos < len(tokens) and tokens[pos] == "if":
        condicional()
    elif pos < len(tokens) and tokens[pos] == "ID":
        asignacion()
    else:
        error("proposicion")


def asignacion():
    parea("ID")
    parea(":=")
    expresion()


def condicional():
    parea("if")
    expresion()
    parea("then")
    proposicion()

    if pos < len(tokens) and tokens[pos] == "else":
        parea("else")
        proposicion()


def expresion():
    global pos
    if pos < len(tokens) and tokens[pos] == "ID":
        parea("ID")
    elif pos < len(tokens) and tokens[pos] == "NUM":
        parea("NUM")
    else:
        error("expresion")


def main():
    global tokens, pos

    print("=== INICIO DEL ANÁLISIS ===\n")

    # Ejemplo de entrada:
    # if x then y := 5 else z := 3
    tokens = ["if", "ID", "then", "ID", ":=", "NUM", "else", "ID", ":=", "NUM"]

    pos = 0

    try:
        proposicion()

        if pos == len(tokens):
            print("\n Cadena aceptada.")
        else:
            print("\n Error: tokens restantes sin consumir.")

    except SyntaxError as e:
        print(f"\n {e}")


# Punto de entrada
if __name__ == "__main__":
    main()
